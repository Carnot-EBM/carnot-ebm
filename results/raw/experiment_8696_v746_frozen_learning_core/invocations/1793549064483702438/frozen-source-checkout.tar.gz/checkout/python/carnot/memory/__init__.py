"""Memory management components."""
