"""Canonical ML metric implementations for Carnot experiment scripts.

**Why this module exists.**
    Per-experiment copy-pasted metric helpers were the antipattern that
    produced the 2026-04-28 inverted-AUROC bug. `exp995` and `exp1003`
    each shipped a `_roc_auc_score` function with a sign error: descending
    sort + `cum_neg[positives].sum()` returns `1 − AUROC` instead of
    `AUROC`. Both verdicts (`tier0f_below_threshold`,
    `live_below_threshold`) were filed with inverted numbers, polluting
    the .77 and .78 milestone narratives. The structural fix is to host
    *one* canonical implementation per metric, exhaustively tested with
    property-based invariants, and forbid per-experiment
    re-implementation in CLAUDE.md.

**Property-based invariants enforced by the tests:**
    - `auroc(y, s) ∈ [0, 1]` always.
    - Perfect separator → 1.0 exactly.
    - Anti-correlated (positives all < negatives) → 0.0 exactly.
    - Single-class input → 0.5 (no-information baseline).
    - Symmetry: `auroc(y, s) + auroc(1 − y, s) ≈ 1.0`.
    - Score-monotonicity: `auroc(y, f(s)) = auroc(y, s)` for any
      strictly monotone-increasing f.
    - sklearn agreement: matches `sklearn.metrics.roc_auc_score`
      within `1e-9` on randomized 100-point corpora.

    The two `_roc_auc_score` bugs would have failed perfect-separator
    *and* symmetry properties immediately. Property tests catch sign
    errors that example tests miss.

Spec: REQ-EVAL-001 (canonical metric implementations),
      REQ-EVAL-002 (property-based invariants),
      REQ-EVAL-003 (sklearn cross-validation).
"""

from __future__ import annotations

from typing import Sequence

import numpy as np

ArrayLike = Sequence[float] | Sequence[int] | np.ndarray


def auroc(y_true: ArrayLike, y_score: ArrayLike) -> float:
    """Area Under the ROC Curve via the Wilcoxon-Mann-Whitney statistic.

    For binary labels in `{0, 1}`, AUROC equals the probability that a
    randomly chosen positive scores higher than a randomly chosen
    negative. Equivalently: count concordant `(positive, negative)`
    pairs (where `score[pos] > score[neg]`) divided by `n_pos · n_neg`.

    Returns `0.5` for degenerate single-class input.

    Implementation: descending-sort scores, then for each positive count
    negatives ranked *after* it (with strictly lower scores). The prior
    bug-pattern in `exp995` and `exp1003` summed `cum_neg[y_sorted == 1]`
    with descending sort, which counts negatives ranked *before* each
    positive — that returns the *complement* of AUROC.
    """
    y_t = np.asarray(y_true, dtype=np.float64)
    y_s = np.asarray(y_score, dtype=np.float64)
    if y_t.shape != y_s.shape:
        raise ValueError(
            f"y_true and y_score must have same shape, got {y_t.shape} vs {y_s.shape}"
        )
    if y_t.ndim != 1:
        raise ValueError(f"expected 1D arrays, got shape {y_t.shape}")

    y_bin = (y_t > 0.5).astype(np.int64)
    n_pos = int(y_bin.sum())
    n_neg = len(y_bin) - n_pos
    if n_pos == 0 or n_neg == 0:
        return 0.5

    desc_idx = np.argsort(-y_s, kind="stable")
    y_sorted = y_bin[desc_idx]
    cum_neg = np.cumsum(1 - y_sorted)
    total_neg = float(cum_neg[-1])
    neg_after = total_neg - cum_neg
    concordant = float(neg_after[y_sorted == 1].sum())
    return concordant / (n_pos * n_neg)


def precision_recall(
    y_true: ArrayLike, y_pred: ArrayLike
) -> tuple[float, float]:
    """Precision and recall for binary classification.

    Returns `(0.0, 0.0)` when denominators are zero (no predicted
    positives or no actual positives) — convention is 0.0 rather than
    NaN since downstream callers expect a number.
    """
    y_t = (np.asarray(y_true, dtype=np.float64) > 0.5).astype(np.int64)
    y_p = (np.asarray(y_pred, dtype=np.float64) > 0.5).astype(np.int64)
    if y_t.shape != y_p.shape:
        raise ValueError(f"shape mismatch: {y_t.shape} vs {y_p.shape}")

    tp = int(((y_t == 1) & (y_p == 1)).sum())
    fp = int(((y_t == 0) & (y_p == 1)).sum())
    fn = int(((y_t == 1) & (y_p == 0)).sum())

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    return precision, recall


def f1_score(y_true: ArrayLike, y_pred: ArrayLike) -> float:
    """Harmonic mean of precision and recall.

    Returns `0.0` when both are zero (the harmonic mean is undefined;
    standard convention is 0.0).
    """
    precision, recall = precision_recall(y_true, y_pred)
    if precision == 0.0 and recall == 0.0:
        return 0.0
    return 2.0 * precision * recall / (precision + recall)


def compute_csr(context_energy: ArrayLike, no_context_energy: ArrayLike) -> float:
    """Context Sensitivity Ratio (CSR) for constraint satisfaction in generation.

    Measures how much the energy drops when context is provided,
    relative to the baseline no-context energy.
    CSR = mean((no_context - context) / no_context).
    
    If no_context_energy is zero, the ratio for that element is 0.0.
    
    Spec: REQ-EVAL-006, SCENARIO-EVAL-006.
    """
    c = np.asarray(context_energy, dtype=np.float64)
    nc = np.asarray(no_context_energy, dtype=np.float64)
    if c.shape != nc.shape:
        raise ValueError(f"shape mismatch: {c.shape} vs {nc.shape}")
    if len(nc) == 0:
        return 0.0
    with np.errstate(divide='ignore', invalid='ignore'):
        ratio = np.where(nc != 0, (nc - c) / nc, 0.0)
    return float(np.mean(ratio))
