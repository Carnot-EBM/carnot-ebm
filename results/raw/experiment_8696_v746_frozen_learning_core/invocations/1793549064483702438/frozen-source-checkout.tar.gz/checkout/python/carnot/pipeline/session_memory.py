"""Multi-session persistence layer for learned pipeline state.

**Researcher summary:**
    CaseMemory (Exp 135) and ConstraintTemplateLibrary (Exp 343) accumulate
    knowledge about model error patterns while a pipeline is running, but
    reset to empty when the process restarts.  SessionMemory provides a
    disk-backed persistence layer so these learned patterns survive across
    sessions: constraint addition thresholds, false-positive calibration,
    and accumulated case clusters all carry forward into the next run.

**Why this matters for the self-learning loop:**
    The autoresearch goal is for Carnot to improve its own verification
    accuracy over time — not just within a single run, but cumulatively.
    Without persistence, every new process is starting from scratch: no
    memory of which constraint types are noisy for which models, no
    accumulated evidence that carry errors are common for small arithmetic
    models, no calibration of FP thresholds.  SessionMemory closes that gap.

**Storage format:**
    Each model gets its own subdirectory so saves for different models never
    interfere.  The state is stored as a single JSON file
    ``(storage_dir)/(safe_model_id)/session_state.json`` with schema version
    "carnot.session_memory.v1".  This is intentionally plain JSON (not
    safetensors) because the data is metadata counts and dictionaries, not
    numeric tensors — plain JSON is human-inspectable and diff-friendly.

**CI-safety contract:**
    ``load()`` NEVER raises; it returns ``None`` on any failure (missing file,
    corrupt JSON, missing keys).  This means experiments and tests that don't
    have pre-existing sessions degrade gracefully rather than crashing.

Spec: REQ-LEARN-020, REQ-LEARN-021,
      SCENARIO-LEARN-035, SCENARIO-LEARN-036, SCENARIO-LEARN-037
"""

from __future__ import annotations

import json
import logging
import pathlib
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from carnot.pipeline.adaptive_thresholds import PerModelFPTracker
    from carnot.pipeline.case_memory import CaseMemory
    from carnot.pipeline.constraint_template_library import ConstraintTemplateLibrary
    from carnot.pipeline.fr11_event_bus import ViolationEvent

_log = logging.getLogger(__name__)

_SCHEMA_VERSION = "carnot.session_memory.v1"
_STATE_FILENAME = "session_state.json"


def _escape_model_id(model_id: str) -> str:
    """Replace forward slashes with '__' so model_id is safe as a directory name.

    **Why this is needed:**
        HuggingFace model IDs often look like "google/gemma-3b".  Using that
        directly as a directory name would create a nested directory structure
        ("google/") that may confuse ``list_sessions()`` and can cause
        cross-platform path issues.  Escaping to "__" is reversible enough for
        display purposes and avoids any filesystem complications.

    Examples:
        "gemma-3b"       → "gemma-3b"
        "google/gemma-3b" → "google__gemma-3b"
        "a/b/c"          → "a__b__c"
    """
    return model_id.replace("/", "__")


class SessionMemory:
    """Persist and restore pipeline learning state across process restarts.

    **Why three components are bundled together:**
        CaseMemory, ConstraintTemplateLibrary, and PerModelFPTracker are the
        three stateful learning components in the pipeline.  They are
        intentionally persisted as a unit because they are coupled: the
        template library's observation counts are driven by CaseMemory
        violation records (via CaseMemoryTemplateWiring), and the FP tracker's
        calibration decisions affect which constraints are applied.  Restoring
        them together ensures the pipeline resumes in a consistent state.

    **Filesystem layout:**
        ``storage_dir/
            <safe_model_id>/
                session_state.json   ← single JSON blob for this model``

    Args:
        storage_dir: Directory under which per-model subdirectories are
                     created.  Created automatically on first ``save()``.
        model_id:    Identifier for the model whose state is being tracked
                     (e.g. "google/gemma-3b").  Forward slashes are escaped.

    Spec: REQ-LEARN-020-1, REQ-LEARN-021-1
    """

    def __init__(self, storage_dir: str, model_id: str) -> None:
        self.storage_dir = storage_dir
        self.model_id = model_id
        # LogicVault properties per agent
        self._z3_solvers: dict[str, Any] = {}
        self._ledger_consistency_rates: dict[str, float] = {}
        self._vault_totals: dict[str, int] = {}
        self._vault_accepteds: dict[str, int] = {}
        self._learned_clauses: dict[str, list[Any]] = {}
        self._search_steps_total: dict[str, int] = {}
        self._last_search_steps: dict[str, int] = {}

    @property
    def ledger_consistency_rate(self) -> float:
        """Backward-compatible property for the default agent's consistency rate."""
        return self._ledger_consistency_rates.get("default", 1.0)

    @ledger_consistency_rate.setter
    def ledger_consistency_rate(self, value: float) -> None:
        """Backward-compatible setter for the default agent's consistency rate."""
        self._ledger_consistency_rates["default"] = value

    def init_logic_vault(self, agent_id: str = "default") -> None:
        """Initialize the Z3 LogicVault for FR-11 for a specific agent."""
        import z3
        self._z3_solvers[agent_id] = z3.Solver()
        self._ledger_consistency_rates[agent_id] = 1.0
        self._vault_totals[agent_id] = 0
        self._vault_accepteds[agent_id] = 0
        self._learned_clauses[agent_id] = []
        self._search_steps_total[agent_id] = 0
        self._last_search_steps[agent_id] = 0

    def add_axiom(self, expr: Any, agent_id: str = "default") -> None:
        """Commit a base axiom to the vault for a specific agent."""
        if agent_id not in self._z3_solvers:
            self.init_logic_vault(agent_id)
        self._z3_solvers[agent_id].add(expr)

    def check_and_admit(self, expr: Any, agent_id: str = "default") -> bool:
        """Check if `expr` is consistent with historical beliefs using Z3.
        If it is, admit it and update ledger_consistency_rate.
        """
        import z3
        if agent_id not in self._z3_solvers:
            self.init_logic_vault(agent_id)

        self._vault_totals[agent_id] += 1
        solver = self._z3_solvers[agent_id]
        
        stats_before = solver.statistics()
        rlimit_before = stats_before.get_key_value('rlimit count') if 'rlimit count' in stats_before.keys() else 0

        solver.push()
        solver.add(expr)
        result = solver.check()

        stats_after = solver.statistics()
        rlimit_after = stats_after.get_key_value('rlimit count') if 'rlimit count' in stats_after.keys() else 0
        steps = rlimit_after - rlimit_before
        self._last_search_steps[agent_id] = steps
        self._search_steps_total[agent_id] += steps

        if result == z3.sat:
            solver.pop()
            solver.add(expr)
            self._vault_accepteds[agent_id] += 1
            self._ledger_consistency_rates[agent_id] = self._vault_accepteds[agent_id] / self._vault_totals[agent_id]
            return True
        else:
            solver.pop()
            # CDCL-inspired constraint learning:
            # We hit a contradiction. We learn z3.Not(expr) and add it as a blocking clause.
            learned_clause = z3.Not(expr)
            self._learned_clauses[agent_id].append(learned_clause)
            solver.add(learned_clause)
            
            self._ledger_consistency_rates[agent_id] = self._vault_accepteds[agent_id] / self._vault_totals[agent_id]
            return False

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _state_path(self) -> pathlib.Path:
        """Return the absolute path to the session state file for this model.

        The model_id is sanitised via ``_escape_model_id`` before use as a
        directory component so that HuggingFace-style "org/model" ids work
        correctly on all platforms.

        Spec: REQ-LEARN-021-1
        """
        safe_id = _escape_model_id(self.model_id)
        return pathlib.Path(self.storage_dir) / safe_id / _STATE_FILENAME

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def on_violation(
        self,
        event: ViolationEvent,
        template_library: ConstraintTemplateLibrary,
    ) -> None:
        """Cache a violation event and call observe_pattern after 5 of the same type.

        **Why 5 violations before calling observe_pattern (REQ-FR11-003):**
            A single violation could be a noise event (FP from the Tier 2.1 probe).
            Requiring 5 violations of the same type before calling observe_pattern
            ensures the pattern is persistent rather than a one-off.  Five is the
            minimum threshold validated across Exps 713-733 for reliable pattern
            emergence without lag.

        **Cross-domain tracking:**
            violations_by_domain tracks how violations spread across question domains
            (e.g. "arithmetic" vs "algebra").  This feeds future cross-domain relay
            experiments (Exp 750+) but has no effect on current routing.

        Args:
            event:            ViolationEvent from FR11EventBus.
            template_library: ConstraintTemplateLibrary to call observe_pattern on.

        Spec: REQ-FR11-003, SCENARIO-FR11-003
        """
        if not hasattr(self, "_violations_by_type"):
            self._violations_by_type: dict[str, int] = {}
        if not hasattr(self, "_violations_by_domain"):
            self._violations_by_domain: dict[str, int] = {}

        ctype = event.constraint_type
        domain = event.question_domain
        self._violations_by_type[ctype] = self._violations_by_type.get(ctype, 0) + 1
        self._violations_by_domain[domain] = self._violations_by_domain.get(domain, 0) + 1

        count = self._violations_by_type[ctype]
        _log.debug(
            "FR11 SessionMemory cached violation: type=%s domain=%s count=%d",
            ctype,
            domain,
            count,
        )

        if count >= 5:
            template_library.observe_pattern(ctype, self.model_id, count)
            _log.info(
                "FR11 SessionMemory called observe_pattern: type=%s model=%s count=%d",
                ctype,
                self.model_id,
                count,
            )

    def persist(self, filepath: str) -> None:
        """Write violation_type → count and template_key mappings to a JSON file.

        WHY this differs from save() (REQ-FR11-005):
            save() serialises the full CaseMemory + ConstraintTemplateLibrary +
            PerModelFPTracker bundle — heavy, requires live objects from the
            pipeline.  persist() writes only the lightweight violation-type
            summary: which constraint types fired and how many times.  This is
            sufficient for cross-session replay: the next session only needs to
            know WHICH templates to pre-activate, not the full observation history.

            The file is created atomically (parent dirs auto-created).  If the
            file already exists it is overwritten so each session_end produces
            the latest snapshot.

        Parameters
        ----------
        filepath : str
            Destination JSON path (e.g. "data/session_memory_persistent.json").

        Spec: REQ-FR11-005, SCENARIO-FR11-005
        """
        violations = getattr(self, "_violations_by_type", {})
        payload: dict[str, Any] = {
            "schema": "carnot.session_memory_relay.v1",
            "model_id": self.model_id,
            "saved_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "violations_by_type": [
                {"violation_type": vtype, "count": count} for vtype, count in violations.items()
            ],
            # template_keys = the subset that reached the threshold (count >= 5).
            "template_keys": [vtype for vtype, count in violations.items() if count >= 5],
        }
        out = pathlib.Path(filepath)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2))
        _log.info("FR11 SessionMemory persisted relay state to %s", filepath)

    def load_relay(
        self,
        filepath: str,
        template_library: ConstraintTemplateLibrary,
    ) -> int:
        """Load persisted violation mappings and replay templates into the library.

        WHY cross-session replay (REQ-FR11-005 / REQ-FR11-006):
            Violation patterns from session S1 are persisted at session_end via
            persist().  At session S2 startup, calling load_relay() restores those
            patterns so templates that fired in S1 are immediately active in S2 —
            the new session starts with pre-warmed constraint knowledge instead of
            cold bootstrap.  This is the "continuous self-learning" milestone: each
            session builds on the last without requiring re-discovery.

            This method is separate from load() (which deserialises the full
            CaseMemory + TemplateLibrary + FPTracker bundle) because relay only
            needs the lightweight violation-type summary.

        Parameters
        ----------
        filepath : str
            Path to the JSON file written by persist().
        template_library : ConstraintTemplateLibrary
            The library to call replay_template() on for each restored key.

        Returns
        -------
        int
            Number of templates successfully replayed (0 when file missing or
            empty — never raises so startup is always safe).

        Spec: REQ-FR11-005, REQ-FR11-006, SCENARIO-FR11-005
        """
        p = pathlib.Path(filepath)
        try:
            raw = p.read_text()
        except (FileNotFoundError, OSError):
            return 0
        try:
            payload = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return 0

        template_keys: list[str] = payload.get("template_keys", [])
        replayed = 0
        for key in template_keys:
            template_library.replay_template(key, self.model_id)
            replayed += 1
            _log.info(
                "FR11 cross-session replay: template %s activated for model %s", key, self.model_id
            )

        # Restore violation counts so on_violation() accumulation is continuous.
        for entry in payload.get("violations_by_type", []):
            vtype = entry.get("violation_type", "")
            count = int(entry.get("count", 0))
            if vtype:
                if not hasattr(self, "_violations_by_type"):
                    self._violations_by_type = {}
                self._violations_by_type[vtype] = max(self._violations_by_type.get(vtype, 0), count)
        return replayed

    def save(
        self,
        case_memory: CaseMemory,
        template_library: ConstraintTemplateLibrary,
        fp_tracker: PerModelFPTracker,
    ) -> None:
        """Serialise all three components to disk.

        **Idempotency guarantee:**
            Calling ``save()`` multiple times always produces a single
            ``session_state.json`` file containing the LATEST state — it
            overwrites any previous save rather than appending.  This means
            callers can ``save()`` after every pipeline ``close()`` without
            worrying about stale data accumulating.

        **Atomic write pattern:**
            We write to the final path directly.  For the learning use case
            the data is small enough that a crash mid-write will produce a
            corrupt file that ``load()`` will safely reject (returning None),
            so the added complexity of a temp-file-then-rename pattern is not
            justified here.

        Args:
            case_memory:      CaseMemory instance to serialise.
            template_library: ConstraintTemplateLibrary instance to serialise.
            fp_tracker:       PerModelFPTracker instance to serialise.

        Spec: REQ-LEARN-020-2, REQ-LEARN-020-3
        """
        path = self._state_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        payload: dict[str, Any] = {
            "schema": _SCHEMA_VERSION,
            "saved_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "case_memory": case_memory.to_dict(),
            "template_library": template_library.to_dict(),
            "fp_tracker": fp_tracker.to_dict(),
        }
        path.write_text(json.dumps(payload, indent=2))

    def load(
        self,
    ) -> tuple[CaseMemory, ConstraintTemplateLibrary, PerModelFPTracker] | None:
        """Deserialise saved state from disk.

        **CI-safety contract:**
            This method NEVER raises.  It returns None for any failure
            condition: missing file, empty file, malformed JSON, missing
            required keys, or unexpected deserialization errors.  This makes
            it safe to call unconditionally at pipeline init without wrapping
            in try/except at the call site.

        Returns:
            A ``(CaseMemory, ConstraintTemplateLibrary, PerModelFPTracker)``
            tuple if state was successfully loaded, or ``None`` otherwise.

        Spec: REQ-LEARN-020-4, REQ-LEARN-020-5
        """
        # Import inside method to avoid circular imports at module load time.
        from carnot.pipeline.adaptive_thresholds import PerModelFPTracker
        from carnot.pipeline.case_memory import CaseMemory
        from carnot.pipeline.constraint_template_library import ConstraintTemplateLibrary

        path = self._state_path()
        try:
            raw = path.read_text()
        except (FileNotFoundError, OSError):
            return None
        try:
            payload = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return None
        try:
            case_memory = CaseMemory.from_dict(payload["case_memory"])
            template_library = ConstraintTemplateLibrary.from_dict(payload["template_library"])
            fp_tracker = PerModelFPTracker.from_dict(payload["fp_tracker"])
        except (KeyError, TypeError, Exception):  # noqa: BLE001 — CI-safety: never raise
            return None
        return case_memory, template_library, fp_tracker

    def write_with_verification(self, repair_text: str, constraint_type: str) -> bool:
        """Accept a repair into memory only if VPRMArithmeticVerifier finds no violations.

        **Why this gate is needed (SRSA memory contamination — arXiv 2603.21558):**
            Without a correctness gate, incorrect repairs produced by the self-play loop
            get written to session memory as positive training examples. Over ~30 steps
            the memory pool accumulates enough corrupted entries to flip the constraint
            weights, causing the fp_rate to trend upward again (the relapse pattern
            observed in Exps 697, 737, and 749).

            This gate applies VPRMArithmeticVerifier.detect_violations() deterministically
            before accepting any repair. If even one arithmetic violation is found in the
            repair text, the repair is discarded and False is returned. Only
            violation-free repairs enter the memory pool.

        **Why VPRM instead of Z3/VeriCoT:**
            VPRM has zero LLM overhead (pure regex + arithmetic identity checks) and
            runs in microseconds. Z3/VeriCoT adds ~100ms per call due to the LLM
            premise-extraction step. For self-play loops running 60+ steps, VPRM
            is the right gate: fast, deterministic, and impossible to reward-hack.

        Args:
            repair_text:     The full repair CoT text to verify before accepting.
            constraint_type: The constraint type label for logging (e.g. "addition").

        Returns:
            True if the repair passed verification and was logged as accepted.
            False if violations were found and the repair was discarded.

        Spec: REQ-PSV-014, REQ-PSV-014-1, REQ-PSV-014-2, REQ-PSV-014-3,
              SCENARIO-PSV-021
        """
        from carnot.extraction.vprm_verifier import VPRMArithmeticVerifier

        verifier = VPRMArithmeticVerifier()
        violations = verifier.detect_violations(repair_text)
        if violations:
            _log.debug(
                "SRSA gate: discarded repair for constraint_type=%s (violations=%d)",
                constraint_type,
                len(violations),
            )
            return False
        _log.debug(
            "SRSA gate: accepted repair for constraint_type=%s",
            constraint_type,
        )
        return True

    def exists(self) -> bool:
        """Return True if a state file exists on disk for this model.

        Spec: REQ-LEARN-020-6
        """
        return self._state_path().exists()

    def clear(self) -> None:
        """Delete the state file for this model if it exists.

        This is a no-op when the file does not exist — callers do not need
        to check ``exists()`` before calling ``clear()``.

        Spec: REQ-LEARN-020-7
        """
        path = self._state_path()
        try:
            path.unlink(missing_ok=True)
        except OSError:
            # Filesystem errors (permissions, etc.) are silently ignored —
            # the goal is best-effort cleanup, not a strict contract.
            pass

    @classmethod
    def list_sessions(cls, storage_dir: str) -> list[str]:
        """Return a sorted list of model identifiers with saved state.

        **What "saved state" means here:**
            Only subdirectories that contain a ``session_state.json`` file
            are included.  Empty or unrelated subdirectories are excluded.

        **Note on model_id escaping:**
            The strings returned are the safe directory-name forms (with
            slashes replaced by ``__``), NOT the original model IDs.  This
            is intentional: the original model_id is not stored in the
            filename, so round-tripping it without ambiguity is not possible
            in the general case.

        Args:
            storage_dir: Root directory to inspect.

        Returns:
            Sorted list of directory names (safe model IDs) that have a
            ``session_state.json``.  Returns ``[]`` if ``storage_dir`` does
            not exist.

        Spec: REQ-LEARN-020-8, SCENARIO-LEARN-037
        """
        root = pathlib.Path(storage_dir)
        if not root.exists():
            return []
        found: list[str] = []
        for candidate in root.iterdir():
            if candidate.is_dir() and (candidate / _STATE_FILENAME).exists():
                found.append(candidate.name)
        return sorted(found)
